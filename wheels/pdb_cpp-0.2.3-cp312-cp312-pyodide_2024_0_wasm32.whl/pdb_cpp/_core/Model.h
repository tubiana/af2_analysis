#ifndef MODEL_H
#define MODEL_H

/**
 * @file Model.h
 * @brief In-memory representation of a single coordinate model/frame.
 */

#pragma once
#include <vector>
#include <string>
#include <array>
#include <unordered_map>

struct Token;

class Model
{
public:
    /** Append one atom to the model. */
    bool addAtom(
        int num,
        const std::array<char, 5> &name_array,
        const std::array<char, 5> &resname_array,
        int res_id,
        const std::array<char, 2> &chain_array,
        float x, float y, float z, float occ, float beta,
        const std::array<char, 2> &alterloc,
        const std::array<char, 5> &elem,
        const std::array<char, 2> &insertres,
        bool field,
        int uniqresid);

    /** Remove all atoms from the model. */
    void clear();
    /** Return the atom count. */
    size_t size() const;
    /** Evaluate a simple column-based selection against explicit values. */
    std::vector<bool> simple_select_atoms(const std::string &column, const std::vector<std::string> &values, const std::string &op) const;
    /** Evaluate a parsed selection token stream. */
    std::vector<bool> select_tokens(const Token &tokens) const;
    /** Evaluate a textual selection expression. */
    std::vector<bool> select_atoms(const std::string selection) const;
    /** Return a filtered copy of the model. */
    Model select_index(const std::vector<bool> &indexes) const;
    /** Return indices matching a selection expression. */
    std::vector<int> get_index_select(const std::string selection) const;

    /** Atom coordinate and annotation accessors. */
    const std::vector<float> &get_x() const { return x_; }
    const std::vector<float> &get_y() const { return y_; }
    const std::vector<float> &get_z() const { return z_; }
    const std::vector<std::array<char, 5>> &get_name() const { return name_; }
    const std::vector<std::array<char, 5>> &get_resname() const { return resname_; }
    const std::vector<int> &get_resid() const { return resid_; }
    const std::vector<std::array<char, 2>> &get_chain() const { return chain_; }
    std::vector<std::string> get_chain_str() const;
    std::string get_chain_id(size_t index) const;
    bool has_chain_id(size_t index) const { return extended_chain_.find(index) != extended_chain_.end(); }
    const std::vector<float> &get_occ() const { return occ_; }
    const std::vector<float> &get_beta() const { return beta_; }
    const std::vector<std::array<char, 2>> &get_alterloc() const { return alterloc_; }
    const std::vector<std::array<char, 2>> &get_insertres() const { return insertres_; }
    const std::vector<std::array<char, 5>> &get_elem() const { return elem_; }
    const std::vector<int> &get_num() const { return num_; }
    const std::vector<bool> &get_field() const { return field_; }
    const std::vector<int> &get_uniqresid() const { return uniqresid_; }
    const std::vector<bool> &get_has_contact() const { return has_contact_; }
    bool has_contact_is_set() const { return !has_contact_.empty(); }

    /** Return the unique chains present in the model. */
    std::vector<std::array<char, 2>> get_uniq_chain() const;

    /** Compute the distance between two atoms. */
    float distance(size_t i, size_t j) const;
    
    /** Compute the centroid over all atoms or a selected subset. */
    std::array<float, 3> get_centroid() const;
    std::array<float, 3> get_centroid(const std::vector<int>& indices) const;

    /** Coordinate setters. */
    void set_x(size_t index, float value) { if (index < x_.size()) x_[index] = value; }
    void set_y(size_t index, float value) { if (index < y_.size()) y_[index] = value; }
    void set_z(size_t index, float value) { if (index < z_.size()) z_[index] = value; }
    void set_num(size_t index, int value) { if (index < num_.size()) num_[index] = value; }
    void set_beta(size_t index, float value) { if (index < beta_.size()) beta_[index] = value; }
    void set_occ(size_t index, float value) { if (index < occ_.size()) occ_[index] = value; }
    void set_resid(size_t index, int value) { if (index < resid_.size()) resid_[index] = value; }
    void set_uniqresid(size_t index, int value) { if (index < uniqresid_.size()) uniqresid_[index] = value; }
    void set_has_contact(size_t index, bool value) {
        if (index >= size()) return;
        if (has_contact_.size() < size()) has_contact_.resize(size(), false);
        has_contact_[index] = value;
    }
    void set_has_contact(const std::vector<bool> &values);

    /** String field setters convert std::string values into fixed-size arrays. */
    void set_name(size_t index, const std::string &value) {
        if (index >= name_.size()) return;
        name_[index] = {};
        for (size_t i = 0; i < std::min(value.size(), (size_t)4); ++i) name_[index][i] = value[i];
    }
    void set_resname(size_t index, const std::string &value) {
        if (index >= resname_.size()) return;
        resname_[index] = {};
        for (size_t i = 0; i < std::min(value.size(), (size_t)4); ++i) resname_[index][i] = value[i];
    }
    void set_elem(size_t index, const std::string &value) {
        if (index >= elem_.size()) return;
        elem_[index] = {};
        for (size_t i = 0; i < std::min(value.size(), (size_t)4); ++i) elem_[index][i] = value[i];
    }
    void set_chain(size_t index, const std::string &value) {
        set_chain_id(index, value);
    }
    void set_chain_id(size_t index, const std::string &value);
    void set_alterloc(size_t index, const std::string &value) {
        if (index >= alterloc_.size()) return;
        alterloc_[index] = {};
        if (!value.empty()) alterloc_[index][0] = value[0];
    }
    void set_insertres(size_t index, const std::string &value) {
        if (index >= insertres_.size()) return;
        insertres_[index] = {};
        if (!value.empty()) insertres_[index][0] = value[0];
    }

private:
    /** Atom-wise storage in a structure-of-arrays layout. */
    std::vector<float> x_, y_, z_, occ_, beta_;
    std::vector<std::array<char, 5>> name_, resname_, elem_;
    std::vector<std::array<char, 2>> chain_, alterloc_, insertres_;
    std::vector<int> num_, resid_, uniqresid_;
    std::vector<bool> field_;
    std::unordered_map<size_t, std::string> extended_chain_;
    std::vector<bool> has_contact_;
};

#endif // MODEL_H