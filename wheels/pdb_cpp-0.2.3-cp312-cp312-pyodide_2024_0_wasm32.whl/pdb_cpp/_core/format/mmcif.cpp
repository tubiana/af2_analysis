#include <algorithm>
#include <cctype>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "mmcif.h"
#include "../Coor.h"
#include "../Model.h"
#include "../geom.h"

using namespace std;

namespace {

bool starts_with(const string &line, const string &prefix) {
    return line.size() >= prefix.size() && line.compare(0, prefix.size(), prefix) == 0;
}

string trim_quotes(const string &value) {
    if (value.size() >= 2) {
        if ((value.front() == '"' && value.back() == '"') ||
            (value.front() == '\'' && value.back() == '\'')) {
            return value.substr(1, value.size() - 2);
        }
    }
    return value;
}

vector<string> split_tokens(const string &line) {
    vector<string> tokens;
    string token;
    bool in_quote = false;
    char quote_char = '\0';

    for (size_t i = 0; i < line.size(); ++i) {
        char ch = line[i];
            // Stop at inline comments when not inside quotes.
            if (!in_quote && ch == '#') {
            break;
        }
        if (in_quote) {
            if (ch == quote_char) {
                in_quote = false;
                tokens.push_back(token);
                token.clear();
            } else {
                token += ch;
            }
            continue;
        }
        // Keep quoted tokens together, excluding the quote characters.
        if (ch == '\'' || ch == '"') {
            in_quote = true;
            quote_char = ch;
            continue;
        }
        if (isspace(static_cast<unsigned char>(ch))) {
            if (!token.empty()) {
                tokens.push_back(token);
                token.clear();
            }
            continue;
        }
        token += ch;
    }
    if (!token.empty()) {
        tokens.push_back(token);
    }
    return tokens;
}

struct LoopTable {
    vector<string> col_names;
    vector<vector<string>> rows;
};

LoopTable parse_loop_for_prefix(const vector<string> &lines, const string &prefix) {
    LoopTable table;

    for (size_t i = 0; i < lines.size(); ++i) {
        string line = lines[i];
        if (!line.empty() && line.back() == '\n') {
            line.pop_back();
        }
        if (!starts_with(line, "loop_")) {
            continue;
        }

        size_t j = i + 1;
        vector<string> col_names;
        bool all_prefix = true;
        bool saw_column = false;

        for (; j < lines.size(); ++j) {
            line = lines[j];
            if (!line.empty() && line.back() == '\n') {
                line.pop_back();
            }
            if (line.empty()) {
                continue;
            }
            if (!starts_with(line, "_")) {
                break;
            }
            saw_column = true;
            if (!starts_with(line, prefix)) {
                all_prefix = false;
            }
            if (all_prefix) {
                vector<string> tokens = split_tokens(line);
                if (tokens.empty()) {
                    continue;
                }
                col_names.push_back(tokens[0].substr(prefix.size()));
            }
        }

        if (!saw_column || !all_prefix || col_names.empty()) {
            for (; j < lines.size(); ++j) {
                line = lines[j];
                if (!line.empty() && line.back() == '\n') {
                    line.pop_back();
                }
                if (starts_with(line, "loop_") || starts_with(line, "_") || starts_with(line, "#")) {
                    i = j - 1;
                    break;
                }
            }
            continue;
        }

        table.col_names = col_names;
        vector<string> pending;
        bool in_multiline = false;
        string multiline_value;

        for (; j < lines.size(); ++j) {
            line = lines[j];
            if (!line.empty() && line.back() == '\n') {
                line.pop_back();
            }

            if (in_multiline) {
                if (starts_with(line, ";")) {
                    in_multiline = false;
                    pending.push_back(multiline_value);
                    multiline_value.clear();
                    if (pending.size() == table.col_names.size()) {
                        table.rows.push_back(pending);
                        pending.clear();
                    }
                    continue;
                }
                multiline_value += line + "\n";
                continue;
            }

            if (line.empty()) {
                continue;
            }
            if (starts_with(line, "loop_") || starts_with(line, "_") || starts_with(line, "#")) {
                return table;
            }
            if (starts_with(line, ";")) {
                in_multiline = true;
                multiline_value = line.substr(1) + "\n";
                continue;
            }

            vector<string> tokens = split_tokens(line);
            if (tokens.empty()) {
                continue;
            }
            pending.insert(pending.end(), tokens.begin(), tokens.end());
            if (pending.size() == table.col_names.size()) {
                table.rows.push_back(pending);
                pending.clear();
            }
        }

        return table;
    }

    return table;
}

unordered_map<string, string> parse_single_value_category(const vector<string> &lines, const string &prefix) {
    unordered_map<string, string> values;
    for (const string &raw : lines) {
        string line = raw;
        if (!line.empty() && line.back() == '\n') {
            line.pop_back();
        }
        if (!starts_with(line, prefix)) {
            continue;
        }
        vector<string> tokens = split_tokens(line);
        if (tokens.size() < 2) {
            continue;
        }
        string key = tokens[0].substr(prefix.size());
        values[key] = tokens[1];
    }
    return values;
}

bool is_missing(const string &value) {
    return value == "." || value == "?";
}

array<char, 5> to_char_array_5(const string &value) {
    array<char, 5> result{};
    size_t count = 0;
    for (char ch : value) {
        if (count >= 4) {
            break;
        }
        result[count++] = ch;
    }
    result[count] = '\0';
    return result;
}

array<char, 2> to_char_array_2(const string &value) {
    array<char, 2> result{};
    if (!value.empty()) {
        result[0] = value[0];
    } else {
        result[0] = ' ';
    }
    result[1] = '\0';
    return result;
}

string sanitize_value(const string &value) {
    if (is_missing(value)) {
        return "";
    }
    return trim_quotes(value);
}

string trim_whitespace(const string &value) {
    size_t start = 0;
    while (start < value.size() && isspace(static_cast<unsigned char>(value[start]))) {
        ++start;
    }
    if (start == value.size()) {
        return "";
    }
    size_t end = value.size();
    while (end > start && isspace(static_cast<unsigned char>(value[end - 1]))) {
        --end;
    }
    return value.substr(start, end - start);
}

} // namespace

Coor MMCIF_parse(const string &filename) {
    Coor coor;
    Model model;
    coor.clear();
    model.clear();

    ifstream file(filename);
    if (!file) {
        cerr << "Error: cannot open file " << filename << endl;
        return coor;
    }

    vector<string> lines;
    string line;
    bool has_contact_category = false;
    while (getline(file, line)) {
        if (starts_with(line, "_pdbx_pdb_cpp_atom_annotation.")) {
            has_contact_category = true;
        }
        lines.push_back(line + "\n");
    }

    LoopTable atom_site = parse_loop_for_prefix(lines, "_atom_site.");
    if (atom_site.col_names.empty()) {
        return coor;
    }

    unordered_map<string, bool> contact_by_atom;
    if (has_contact_category) {
        LoopTable annotations = parse_loop_for_prefix(lines, "_pdbx_pdb_cpp_atom_annotation.");
        unordered_map<string, size_t> annotation_index;
        for (size_t i = 0; i < annotations.col_names.size(); ++i) {
            annotation_index[annotations.col_names[i]] = i;
        }
        auto annotation_value = [&](const vector<string> &row, const string &key) -> string {
            auto it = annotation_index.find(key);
            return it == annotation_index.end() || it->second >= row.size() ? "" : row[it->second];
        };
        for (const auto &row : annotations.rows) {
            string atom_id = sanitize_value(annotation_value(row, "atom_site_id"));
            string model_id = sanitize_value(annotation_value(row, "pdbx_PDB_model_num"));
            string value = sanitize_value(annotation_value(row, "has_contact"));
            if (!atom_id.empty() && !model_id.empty()) {
                contact_by_atom[model_id + ":" + atom_id] = value == "1" || value == "yes" || value == "true";
            }
        }
    }

    unordered_map<string, size_t> col_index;
    for (size_t i = 0; i < atom_site.col_names.size(); ++i) {
        col_index[atom_site.col_names[i]] = i;
    }

    auto get_value = [&](const vector<string> &row, const string &key) -> string {
        auto it = col_index.find(key);
        if (it == col_index.end()) {
            return "";
        }
        if (it->second >= row.size()) {
            return "";
        }
        return row[it->second];
    };

    int uniq_resid = -1;
    int old_resid = -99999999;
    string old_chain;
    int old_model = -1;
    auto attach_contact_annotations = [&](Model &target, int model_number) {
        if (!has_contact_category) return;
        vector<bool> values;
        values.reserve(target.size());
        const string model_id = to_string(model_number);
        for (int atom_id : target.get_num()) {
            auto contact = contact_by_atom.find(model_id + ":" + to_string(atom_id));
            values.push_back(contact != contact_by_atom.end() && contact->second);
        }
        target.set_has_contact(values);
    };

    for (const auto &row : atom_site.rows) {
        string group_pdb = sanitize_value(get_value(row, "group_PDB"));
        bool field = (group_pdb == "HETATM");

        string num_str = sanitize_value(get_value(row, "id"));
        string name = sanitize_value(get_value(row, "label_atom_id"));
        string resname = sanitize_value(get_value(row, "label_comp_id"));
        string altloc = sanitize_value(get_value(row, "label_alt_id"));
        string chain_label = sanitize_value(get_value(row, "label_asym_id"));
        string chain_auth = sanitize_value(get_value(row, "auth_asym_id"));
        string resid_str = sanitize_value(get_value(row, "auth_seq_id"));
        string insert_res = sanitize_value(get_value(row, "pdbx_PDB_ins_code"));
        string elem = sanitize_value(get_value(row, "type_symbol"));

        string model_str = sanitize_value(get_value(row, "pdbx_PDB_model_num"));

        int num = num_str.empty() ? 0 : stoi(num_str);
        int resid = resid_str.empty() ? 0 : stoi(resid_str);
        int model_num = model_str.empty() ? 1 : stoi(model_str);

        if (chain_auth.empty()) {
            chain_auth = chain_label;
        }

        // Split models based on pdbx_PDB_model_num.
        if (model_num != old_model) {
            if (model.size() > 0) {
                attach_contact_annotations(model, old_model);
                coor.add_Model(model);
                model.clear();
            }
            uniq_resid = -1;
            old_resid = -99999999;
            old_chain.clear();
            old_model = model_num;
        }

        // Increment unique residue when residue id or chain changes.
        if (resid != old_resid || chain_auth != old_chain) {
            ++uniq_resid;
            old_resid = resid;
            old_chain = chain_auth;
        }

        string x_str = sanitize_value(get_value(row, "Cartn_x"));
        string y_str = sanitize_value(get_value(row, "Cartn_y"));
        string z_str = sanitize_value(get_value(row, "Cartn_z"));
        float x = x_str.empty() ? 0.0f : stof(x_str);
        float y = y_str.empty() ? 0.0f : stof(y_str);
        float z = z_str.empty() ? 0.0f : stof(z_str);

        string occ_str = sanitize_value(get_value(row, "occupancy"));
        string beta_str = sanitize_value(get_value(row, "B_iso_or_equiv"));
        float occ = occ_str.empty() ? 0.0f : stof(occ_str);
        float beta = beta_str.empty() ? 0.0f : stof(beta_str);

        array<char, 5> name_array = to_char_array_5(name);
        array<char, 5> resname_array = to_char_array_5(resname);
        array<char, 5> elem_array = to_char_array_5(elem);
        array<char, 2> alterloc_array = to_char_array_2(altloc);
        array<char, 2> chain_array = to_char_array_2(chain_label);
        array<char, 2> insert_array = to_char_array_2(insert_res);

        model.addAtom(
            num,
            name_array,
            resname_array,
            resid,
            chain_array,
            x, y, z, occ, beta,
            alterloc_array,
            elem_array,
            insert_array,
            field,
            uniq_resid
        );
        if (chain_label.size() > 1) {
            model.set_chain_id(model.size() - 1, chain_label);
        }
    }

    if (model.size() > 0) {
        attach_contact_annotations(model, old_model);
        coor.add_Model(model);
    }

    // Parse _struct_conn for bond/CONECT records.
    LoopTable struct_conn = parse_loop_for_prefix(lines, "_struct_conn.");
    if (!struct_conn.col_names.empty() && coor.model_size() > 0) {
        unordered_map<string, size_t> sc_index;
        for (size_t i = 0; i < struct_conn.col_names.size(); ++i) {
            sc_index[struct_conn.col_names[i]] = i;
        }
        auto get_sc_value = [&](const vector<string> &row, const string &key) -> string {
            auto it = sc_index.find(key);
            if (it == sc_index.end() || it->second >= row.size()) {
                return "";
            }
            return row[it->second];
        };

        // Build lookup: (chain, resid, atom_name) -> serial number from model 0.
        const Model &model0 = coor.get_Models(0);
        unordered_map<string, int> atom_lookup;
        for (size_t i = 0; i < model0.size(); ++i) {
            string chain_s = trim_whitespace(string(model0.get_chain()[i].data()));
            string name_s = trim_whitespace(string(model0.get_name()[i].data()));
            int resid_val = model0.get_resid()[i];
            string altloc_s = trim_whitespace(string(model0.get_alterloc()[i].data()));
            string key = chain_s + ":" + to_string(resid_val) + ":" + name_s;
            if (!altloc_s.empty()) {
                key += ":" + altloc_s;
            }
            // Store only the first occurrence (in case of duplicate keys).
            if (atom_lookup.find(key) == atom_lookup.end()) {
                atom_lookup[key] = model0.get_num()[i];
            }
        }

        for (const auto &sc_row : struct_conn.rows) {
            // Partner 1: prefer label_asym_id (matches stored chain), auth_seq_id, label_atom_id.
            string p1_chain = sanitize_value(get_sc_value(sc_row, "ptnr1_label_asym_id"));
            string p1_resid_str = sanitize_value(get_sc_value(sc_row, "ptnr1_auth_seq_id"));
            string p1_atom = sanitize_value(get_sc_value(sc_row, "ptnr1_label_atom_id"));
            string p1_alt = sanitize_value(get_sc_value(sc_row, "pdbx_ptnr1_label_alt_id"));

            // Partner 2.
            string p2_chain = sanitize_value(get_sc_value(sc_row, "ptnr2_label_asym_id"));
            string p2_resid_str = sanitize_value(get_sc_value(sc_row, "ptnr2_auth_seq_id"));
            string p2_atom = sanitize_value(get_sc_value(sc_row, "ptnr2_label_atom_id"));
            string p2_alt = sanitize_value(get_sc_value(sc_row, "pdbx_ptnr2_label_alt_id"));

            if (p1_chain.empty() || p1_resid_str.empty() || p1_atom.empty() ||
                p2_chain.empty() || p2_resid_str.empty() || p2_atom.empty()) {
                continue;
            }

            string key1 = p1_chain + ":" + p1_resid_str + ":" + p1_atom;
            string key2 = p2_chain + ":" + p2_resid_str + ":" + p2_atom;
            if (!p1_alt.empty()) key1 += ":" + p1_alt;
            if (!p2_alt.empty()) key2 += ":" + p2_alt;

            auto it1 = atom_lookup.find(key1);
            auto it2 = atom_lookup.find(key2);
            if (it1 == atom_lookup.end() || it2 == atom_lookup.end()) {
                continue;
            }

            int serial1 = it1->second;
            int serial2 = it2->second;
            // Add bidirectional bond.
            coor.conect[serial1].push_back(serial2);
            coor.conect[serial2].push_back(serial1);
        }
    }

    auto cell_values = parse_single_value_category(lines, "_cell.");
    if (!cell_values.empty() &&
        cell_values.find("length_a") != cell_values.end() &&
        cell_values.find("length_b") != cell_values.end() &&
        cell_values.find("length_c") != cell_values.end() &&
        cell_values.find("angle_alpha") != cell_values.end() &&
        cell_values.find("angle_beta") != cell_values.end() &&
        cell_values.find("angle_gamma") != cell_values.end()) {
        float a = stof(cell_values["length_a"]);
        float b = stof(cell_values["length_b"]);
        float c = stof(cell_values["length_c"]);
        float alpha = stof(cell_values["angle_alpha"]);
        float beta = stof(cell_values["angle_beta"]);
        float gamma = stof(cell_values["angle_gamma"]);
        int z = 1;
        auto z_it = cell_values.find("Z_PDB");
        if (z_it != cell_values.end()) {
            string z_value = trim_whitespace(trim_quotes(z_it->second));
            if (!z_value.empty() && z_value != "?" && z_value != ".") {
                try {
                    z = stoi(z_value);
                } catch (const std::exception &) {
                    z = 1;
                }
            }
        }

        string sgroup = "P 1";
        auto sym_values = parse_single_value_category(lines, "_symmetry.");
        auto sg_it = sym_values.find("space_group_name_H-M");
        if (sg_it != sym_values.end()) {
            sgroup = trim_quotes(sg_it->second);
        }

        ostringstream cryst;
        cryst << "CRYST1"
              << setw(9) << fixed << setprecision(3) << a
              << setw(9) << fixed << setprecision(3) << b
              << setw(9) << fixed << setprecision(3) << c
              << setw(7) << fixed << setprecision(2) << alpha
              << setw(7) << fixed << setprecision(2) << beta
              << setw(7) << fixed << setprecision(2) << gamma
              << " " << left << setw(9) << sgroup
              << right << setw(3) << z << "\n";
        coor.crystal_pack.set_CRYST1_pdb(cryst.str());
    }

    LoopTable assembly_gen = parse_loop_for_prefix(lines, "_pdbx_struct_assembly_gen.");
    LoopTable oper_list = parse_loop_for_prefix(lines, "_pdbx_struct_oper_list.");

    if (!assembly_gen.col_names.empty() && !oper_list.col_names.empty()) {
        unordered_map<string, size_t> oper_index;
        for (size_t i = 0; i < oper_list.col_names.size(); ++i) {
            oper_index[oper_list.col_names[i]] = i;
        }

        unordered_map<string, vector<vector<float>>> matrices;
        auto get_oper_val = [&](const vector<string> &row, const string &key) -> string {
            auto it = oper_index.find(key);
            if (it == oper_index.end()) {
                return "";
            }
            if (it->second >= row.size()) {
                return "";
            }
            return row[it->second];
        };

        for (const auto &row : oper_list.rows) {
            string id = sanitize_value(get_oper_val(row, "id"));
            if (id.empty()) {
                continue;
            }
            vector<vector<float>> matrix_rows;
            for (int i = 1; i <= 3; ++i) {
                vector<float> row_vals;
                for (int j = 1; j <= 3; ++j) {
                    string key = "matrix[" + to_string(i) + "][" + to_string(j) + "]";
                    row_vals.push_back(stof(sanitize_value(get_oper_val(row, key))));
                }
                string vec_key = "vector[" + to_string(i) + "]";
                row_vals.push_back(stof(sanitize_value(get_oper_val(row, vec_key))));
                matrix_rows.push_back(row_vals);
            }
            matrices[id] = matrix_rows;
        }

        unordered_map<string, size_t> gen_index;
        for (size_t i = 0; i < assembly_gen.col_names.size(); ++i) {
            gen_index[assembly_gen.col_names[i]] = i;
        }

        auto get_gen_val = [&](const vector<string> &row, const string &key) -> string {
            auto it = gen_index.find(key);
            if (it == gen_index.end()) {
                return "";
            }
            if (it->second >= row.size()) {
                return "";
            }
            return row[it->second];
        };

        if (!assembly_gen.rows.empty()) {
            const auto &row = assembly_gen.rows.front();
            string chains_str = sanitize_value(get_gen_val(row, "asym_id_list"));
            string oper_expr = sanitize_value(get_gen_val(row, "oper_expression"));

            vector<string> chains;
            if (!chains_str.empty()) {
                string token;
                istringstream ss(chains_str);
                while (getline(ss, token, ',')) {
                    token.erase(token.begin(), find_if(token.begin(), token.end(), [](unsigned char ch) { return !isspace(ch); }));
                    token.erase(find_if(token.rbegin(), token.rend(), [](unsigned char ch) { return !isspace(ch); }).base(), token.end());
                    if (!token.empty()) {
                        chains.push_back(token);
                    }
                }
            }

            vector<string> oper_ids;
            if (!oper_expr.empty()) {
                string token;
                istringstream ss(oper_expr);
                while (getline(ss, token, ',')) {
                    token.erase(remove(token.begin(), token.end(), '('), token.end());
                    token.erase(remove(token.begin(), token.end(), ')'), token.end());
                    token.erase(token.begin(), find_if(token.begin(), token.end(), [](unsigned char ch) { return !isspace(ch); }));
                    token.erase(find_if(token.rbegin(), token.rend(), [](unsigned char ch) { return !isspace(ch); }).base(), token.end());
                    if (!token.empty()) {
                        oper_ids.push_back(token);
                    }
                }
            }

            coor.transformation.clear();
            coor.transformation.set_chains(chains);
            for (const auto &oper_id : oper_ids) {
                auto it = matrices.find(oper_id);
                if (it == matrices.end()) {
                    continue;
                }
                for (const auto &row_vals : it->second) {
                    coor.transformation.add_matrix_row(row_vals);
                }
            }
        }
    }

    return coor;
}

string get_mmcif_string(const Coor &coor) {
    ostringstream oss;
    oss << "data_XXXX\n#\n";
    // Emit a minimal atom_site loop for round-trip support.
    oss << "loop_\n"
        << "_atom_site.group_PDB\n"
        << "_atom_site.id\n"
        << "_atom_site.type_symbol\n"
        << "_atom_site.label_atom_id\n"
        << "_atom_site.label_alt_id\n"
        << "_atom_site.label_comp_id\n"
        << "_atom_site.label_asym_id\n"
        << "_atom_site.label_entity_id\n"
        << "_atom_site.label_seq_id\n"
        << "_atom_site.pdbx_PDB_ins_code\n"
        << "_atom_site.Cartn_x\n"
        << "_atom_site.Cartn_y\n"
        << "_atom_site.Cartn_z\n"
        << "_atom_site.occupancy\n"
        << "_atom_site.B_iso_or_equiv\n"
        << "_atom_site.pdbx_formal_charge\n"
        << "_atom_site.auth_seq_id\n"
        << "_atom_site.auth_comp_id\n"
        << "_atom_site.auth_asym_id\n"
        << "_atom_site.auth_atom_id\n"
        << "_atom_site.pdbx_PDB_model_num\n";

    for (size_t model_index = 0; model_index < coor.model_size(); ++model_index) {
        const Model &model = coor.get_Models(model_index);
        for (size_t i = 0; i < model.size(); ++i) {
            string group = model.get_field()[i] ? "HETATM" : "ATOM";
            string name = trim_whitespace(string(model.get_name()[i].data()));
            string resname = trim_whitespace(string(model.get_resname()[i].data()));
            string chain = model.get_chain_id(i);
            string altloc = trim_whitespace(string(model.get_alterloc()[i].data()));
            string insertres = trim_whitespace(string(model.get_insertres()[i].data()));
            string elem = trim_whitespace(string(model.get_elem()[i].data()));

            if (altloc.empty()) {
                altloc = ".";
            }
            if (insertres.empty()) {
                insertres = "?";
            }
            if (elem.empty()) {
                elem = "?";
            }

            oss << group << " "
                << model.get_num()[i] << " "
                << elem << " "
                << name << " "
                << altloc << " "
                << resname << " "
                << chain << " "
                << "1" << " "
                << model.get_uniqresid()[i] + 1 << " "
                << insertres << " "
                << fixed << setprecision(3) << model.get_x()[i] << " "
                << fixed << setprecision(3) << model.get_y()[i] << " "
                << fixed << setprecision(3) << model.get_z()[i] << " "
                << fixed << setprecision(2) << model.get_occ()[i] << " "
                << fixed << setprecision(2) << model.get_beta()[i] << " "
                << "?" << " "
                << model.get_resid()[i] << " "
                << resname << " "
                << chain << " "
                << name << " "
                << (model_index + 1) << "\n";
        }
    }

    oss << "#\n";

    bool annotations_set = false;
    for (size_t model_index = 0; model_index < coor.model_size(); ++model_index) {
        annotations_set = annotations_set || coor.get_Models(model_index).has_contact_is_set();
    }
    if (annotations_set) {
        oss << "loop_\n"
            << "_pdbx_pdb_cpp_atom_annotation.atom_site_id\n"
            << "_pdbx_pdb_cpp_atom_annotation.pdbx_PDB_model_num\n"
            << "_pdbx_pdb_cpp_atom_annotation.has_contact\n";
        for (size_t model_index = 0; model_index < coor.model_size(); ++model_index) {
            const Model &model = coor.get_Models(model_index);
            for (size_t i = 0; i < model.size(); ++i) {
                bool value = model.has_contact_is_set() && model.get_has_contact()[i];
                oss << model.get_num()[i] << " " << (model_index + 1) << " " << (value ? 1 : 0) << "\n";
            }
        }
        oss << "#\n";
    }

    // Write _struct_conn loop for CONECT records.
    if (!coor.conect.empty() && coor.model_size() > 0) {
        const Model &model0 = coor.get_Models(0);

        // Build serial number -> position index map for model 0.
        unordered_map<int, size_t> serial_to_idx;
        for (size_t i = 0; i < model0.size(); ++i) {
            serial_to_idx[model0.get_num()[i]] = i;
        }

        // Collect unique bond pairs (smaller serial first) to avoid duplicates.
        set<pair<int, int>> unique_bonds;
        vector<int> keys;
        keys.reserve(coor.conect.size());
        for (const auto &kv : coor.conect) {
            keys.push_back(kv.first);
        }
        sort(keys.begin(), keys.end());
        for (int atom_idx : keys) {
            const vector<int> &bonded = coor.conect.at(atom_idx);
            for (int partner : bonded) {
                int lo = min(atom_idx, partner);
                int hi = max(atom_idx, partner);
                unique_bonds.insert({lo, hi});
            }
        }

        if (!unique_bonds.empty()) {
            oss << "loop_\n"
                << "_struct_conn.id\n"
                << "_struct_conn.conn_type_id\n"
                << "_struct_conn.ptnr1_label_asym_id\n"
                << "_struct_conn.ptnr1_label_comp_id\n"
                << "_struct_conn.ptnr1_label_seq_id\n"
                << "_struct_conn.ptnr1_label_atom_id\n"
                << "_struct_conn.pdbx_ptnr1_label_alt_id\n"
                << "_struct_conn.ptnr1_auth_asym_id\n"
                << "_struct_conn.ptnr1_auth_comp_id\n"
                << "_struct_conn.ptnr1_auth_seq_id\n"
                << "_struct_conn.ptnr1_symmetry\n"
                << "_struct_conn.ptnr2_label_asym_id\n"
                << "_struct_conn.ptnr2_label_comp_id\n"
                << "_struct_conn.ptnr2_label_seq_id\n"
                << "_struct_conn.ptnr2_label_atom_id\n"
                << "_struct_conn.pdbx_ptnr2_label_alt_id\n"
                << "_struct_conn.ptnr2_auth_asym_id\n"
                << "_struct_conn.ptnr2_auth_comp_id\n"
                << "_struct_conn.ptnr2_auth_seq_id\n"
                << "_struct_conn.ptnr2_symmetry\n";

            int conn_id = 1;
            for (const auto &bond : unique_bonds) {
                auto it1 = serial_to_idx.find(bond.first);
                auto it2 = serial_to_idx.find(bond.second);
                if (it1 == serial_to_idx.end() || it2 == serial_to_idx.end()) {
                    continue;
                }
                size_t idx1 = it1->second;
                size_t idx2 = it2->second;

                string chain1 = model0.get_chain_id(idx1);
                string resname1 = trim_whitespace(string(model0.get_resname()[idx1].data()));
                string name1 = trim_whitespace(string(model0.get_name()[idx1].data()));
                string altloc1 = trim_whitespace(string(model0.get_alterloc()[idx1].data()));
                int resid1 = model0.get_resid()[idx1];
                int uniqresid1 = model0.get_uniqresid()[idx1] + 1;

                string chain2 = model0.get_chain_id(idx2);
                string resname2 = trim_whitespace(string(model0.get_resname()[idx2].data()));
                string name2 = trim_whitespace(string(model0.get_name()[idx2].data()));
                string altloc2 = trim_whitespace(string(model0.get_alterloc()[idx2].data()));
                int resid2 = model0.get_resid()[idx2];
                int uniqresid2 = model0.get_uniqresid()[idx2] + 1;

                if (altloc1.empty()) altloc1 = "?";
                if (altloc2.empty()) altloc2 = "?";

                oss << "covale" << conn_id << " covale "
                    << chain1 << " " << resname1 << " " << uniqresid1 << " " << name1 << " " << altloc1 << " "
                    << chain1 << " " << resname1 << " " << resid1 << " 1_555 "
                    << chain2 << " " << resname2 << " " << uniqresid2 << " " << name2 << " " << altloc2 << " "
                    << chain2 << " " << resname2 << " " << resid2 << " 1_555\n";
                ++conn_id;
            }
            oss << "#\n";
        }
    }

    return oss.str();
}

bool MMCIF_write(const Coor &coor, const string &filename) {
    ofstream file(filename);
    if (!file) {
        cerr << "Error: cannot open file " << filename << endl;
        return false;
    }
    file << get_mmcif_string(coor);
    return true;
}
